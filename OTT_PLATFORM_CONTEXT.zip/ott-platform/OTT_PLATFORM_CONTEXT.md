# OTT Platform — Project Context Guide
## For continuing this project in a new Claude session

---

## Project Overview

A production-ready Netflix/JioCinema-style OTT streaming platform built across multiple Claude chat sessions.

**Domain:** `ssooss.store`
**VPS:** Hetzner CX23 (3 ARM vCPU, 8GB RAM) — Ubuntu 24.04
**Storage:** Cloudflare R2 (free egress)
**Stack:** NestJS + PostgreSQL + Redis + FFmpeg + React + Kotlin Android

---

## Current Completion: ~68%

### ✅ COMPLETED PHASES

#### Phase 1 — Architecture Blueprint
- Complete system architecture diagram
- Full PostgreSQL schema (20+ tables)
- Docker Compose (all services)
- Nginx config with Cloudflare real-IP handling
- R2 bucket folder structure
- Cloudflare cache rules
- VPS sizing recommendations
- Security checklist
- Deployment order
- `.env.example` with all variables

#### Phase 2A — NestJS API Core (91 backend files)
- `main.ts` — Helmet, CORS (domain-whitelisted), Morgan, global pipes/filters/interceptors
- `app.module.ts` — TypeORM (PG pool=20), BullMQ, Throttler, SearchSyncListener
- **Auth module:** JWT (15m access) + refresh token rotation (30d), device fingerprinting, replay attack protection (revoke-all on reuse), bcrypt 12 rounds
- **Users module:** CRUD, password change, device management (max per plan), FCM token
- **Content module:** Movies, series, seasons, episodes, genres, watch history (upsert), watchlist, continue-watching, homepage feeds (trending/featured/recent)
- **Streaming module:** HMAC-SHA256 signed HLS URLs, m3u8 rewriter (injects tokens into all segment URLs), `/stream/verify` for Nginx auth_request
- **Common layer:** `JwtAuthGuard` (@Public() decorator), `RolesGuard`, `SubscriptionGuard`, `PremiumGuard`, `DeviceLimitGuard`, `DeviceFingerprintMiddleware`, `TransformInterceptor` (standard envelope), `LoggingInterceptor`, `HttpExceptionFilter` (TypeORM error mapping), `CurrentUser` decorator
- **Health module:** `/health/live`, `/health/ready`, `/health` (DB + memory + disk)
- **Metrics module:** Prometheus counters/gauges/histograms (streams, auth failures, transcode jobs)

#### Phase 2B — FFmpeg Transcoding Worker (15 files)
- BullMQ Worker (concurrency=2, stall detection, lock 1h)
- **7-stage pipeline:** download R2 → probe → transcode × 4 renditions → extract audio → extract subtitles → thumbnails+sprite → upload all to R2
- `ffmpeg.service.ts` — `transcodeRendition()` per profile, `buildMasterPlaylist()` (HLS master with audio groups + subtitle groups), `extractAudioTracks()`, `extractSubtitles()` (WebVTT)
- `thumbnail.service.ts` — poster (300×450 WebP), banner (1280×720 WebP), thumb (320×180 WebP), sprite sheet (160×90 tiles, 10s interval, sprite.vtt with `#xywh=` coordinates)
- `r2.service.ts` — multipart upload with `p-limit` concurrency, streaming download, directory upload, mime-type/cache-control mapping
- `cpu-guard.ts` — reads `/proc/stat` + `/proc/meminfo`, blocks new FFmpeg jobs above 80% CPU / 85% RAM
- Worker Dockerfile: node:20-alpine + ffmpeg + ffprobe + vips (for Sharp)
- Prometheus metrics endpoint at `:9091/metrics`

**Rendition profiles:**
```
1080p: 5000k video, 192k audio, CRF 23, preset faster
720p:  2800k video, 128k audio, CRF 23, preset faster
480p:  1400k video, 128k audio, CRF 24, preset faster
360p:   800k video,  96k audio, CRF 25, preset faster
```
All: 6s HLS segments, H.264 high profile, AAC 44100Hz, GOP = fps×6, independent segments

#### Phase 2C — React CMS Admin Panel (33 files)
- **Stack:** Vite + React 18 + Tailwind CSS + TanStack Query + Zustand + React Hook Form + Zod + Recharts
- **Design system:** Netflix dark theme (OttColors), `cn()` utility, all UI primitives (Button, Badge, StatusBadge, Input, Textarea, Select, Card, StatCard, ProgressBar, Spinner, EmptyState, ConfirmDialog)
- **Pages:** Dashboard (stats grid, area chart plays/users, bar chart resolutions, recent jobs), Movies/Series list (search, filter, sort, paginate, delete), ContentForm (create/edit with genre multi-select, toggle flags), UploadPage, EncodingQueue (live 5s poll, job expand, retry), UserManagement, NotificationsPage (FCM topic/user/all), SettingsPage (app config, R2, SMTP), SubscriptionsPage (stats, revenue, coupon CRUD)
- **VideoUploader component:** Drag-drop via react-dropzone, 100MB chunks, 3 parallel parts, direct to R2 presigned URLs (bypasses API), progress tracking, transcode polling every 5s
- **Axios client:** JWT attach + silent refresh on 401, request queue during refresh
- **Zustand stores:** `auth.store` (localStorage persist), `upload.store` (per-upload progress + transcode state)
- **Router:** React Router v6 with lazy-loaded pages, auth guard (role check), redirects

#### Phase 2D — Android App (49 files)
- **Stack:** Kotlin, Jetpack Compose, Hilt, Retrofit, Room, Media3 ExoPlayer, Coil, DataStore, Coroutines
- **Architecture:** Clean — data (DTOs + Room + repositories) → domain (models + interfaces) → presentation (ViewModels + Compose screens)
- **DTOs:** `AuthDto.kt`, `ContentDto.kt` (Content, Season, Episode, VideoAsset, Rendition, Subtitle, AudioTrack, WatchHistory, SubscriptionPlan, CreateOrderResponse)
- **API:** `OttApiService.kt` — 40+ Retrofit endpoints
- **Auth interceptor:** Silent refresh with request queue, replay-safe, no-recursion (uses bare OkHttpClient for refresh call)
- **Token storage:** DataStore preferences (not SharedPreferences)
- **Room DB:** `CachedContentEntity`, `WatchProgressEntity`, `SearchHistoryEntity` + DAOs
- **Repositories:** Auth, Content (network-bound flow: emit cache → fetch → re-emit), Watch (local-first progress), Stream (builds StreamSession), Subscription
- **Hilt modules:** NetworkModule (OkHttp + Retrofit), DatabaseModule (Room), RepositoryModule (bindings)
- **ExoPlayerManager:** Singleton, HLS via OkHttp datasource (JWT headers), DefaultTrackSelector for quality, subtitle/audio language routing, intro skip tick, position/duration state
- **Screens:** Splash (spring animation), Login/Register (edge-to-edge, keyboard-aware), Home (HorizontalPager hero, auto-scroll 5s, ContentRow carousels, WideCard with progress bar, skeleton loader), ContentDetail (banner, meta, play/watchlist, season tabs, episode rows), Player (full Compose overlay, gradient controls, SeekBar Slider, TrackSelectionSheet, intro skip button, next episode), Search (debounced, result rows), Profile (menu sections, logout), Subscription (plan cards, coupon input, Razorpay checkout)
- **Services:** OttFcmService (token refresh → API sync), NotificationHelper, MediaPlaybackService (Media3 session)

#### Phase 2E — Subscriptions + Payments
- **Entities:** `SubscriptionPlanEntity`, `SubscriptionEntity` (+ Play token field), `PaymentEntity` (gateway enum: razorpay/google_play/free, coupon tracking, invoice fields), `CouponEntity` (percent/flat, per-plan restriction, max-uses)
- **RazorpayService:** Order creation, HMAC-SHA256 constant-time signature verify, payment fetch, webhook verify, refund
- **GooglePlayService:** androidpublisher v3 REST verification via service account JWT, purchase acknowledgement
- **CouponsService:** Validate (no redeem), redeem (atomic increment), admin CRUD
- **InvoiceService:** HTML invoice builder → R2 upload (private cache), updates payment record
- **SubscriptionsService:** Free trial (one per account), order create, Razorpay verify (DB transaction: expire old → create new), Play Billing verify + acknowledge, cancel, `expireStaleSubscriptions()`
- **Guards:** `PremiumGuard` (DB-authoritative, not just JWT), `DeviceLimitGuard` (per-plan max devices)
- **Scheduler:** `@Cron(EVERY_HOUR)` expiry + daily revenue log
- **SQL Migration 002:** Coupon table, payment columns, `active_subscribers` view

#### Phase 2F — Search + Recommendations (partial — backend complete, Android pending)
- **MeilisearchService:** Full index config (searchable, filterable, sortable attributes, typo tolerance, custom ranking), bulk index, single doc index/delete, search with filters, autocomplete suggest, get-by-IDs
- **SearchService:** Full search (records analytics async), suggest, trending queries, `reindexAll()` (batch 100), `indexContent()` per content, `removeFromIndex()`
- **SearchSyncListener:** TypeORM EntitySubscriber — auto-syncs INSERT/UPDATE/DELETE to Meilisearch with 500ms defer
- **RecommendationsService:**
  - `getTrending()` — SQL score: `recent_plays×2 + total×0.1 + imdb×10`
  - `getContinueWatching()` — incomplete items with >30s watched
  - `getBecauseYouWatched()` — genre overlap from last 5 watched titles
  - `getSimilar()` — Meilisearch by genres, DB fallback
  - `getTopRated()` — IMDb ≥ 7.0 ordered by rating+plays
  - `getNewReleases()` — published in last 30 days
  - `getPopularInLanguage()` — per-language plays ranking
  - `getPersonalisedByGenre()` — top genres from 30-day history → per-genre rows
  - 10-minute in-memory cache per user
- **RecommendationsController:** All endpoints, @Public() on most (auth optional)

---

### ❌ NOT YET BUILT (remaining ~32%)

#### Phase 2F Remaining
- **Android:** `OttApiService` recommendations endpoints, `RecommendationRepository`, updated `HomeViewModel` to call recommendations API instead of content API directly, updated `HomeScreen` to show "Because You Watched" and genre rows from API

#### Phase 2G — Streaming Security
- Cloudflare WAF rules for HLS token validation
- Nginx `auth_request` for every HLS segment (currently only endpoint exists, not wired into nginx)
- Concurrent stream limit enforcement (max 3 per subscription)
- DRM-ready ExoPlayer architecture (Widevine L3 MediaDrm callback)
- Device session tracking in Redis (stream token → device fingerprint)

#### Phase 2H — Analytics + Grafana
- Play event tracking (start, pause, seek, quality-change, buffering, complete)
- Buffering rate analytics
- CDN hit ratio tracking
- Grafana dashboard JSONs (concurrent viewers, transcoding queue, revenue, user growth)
- Prometheus alert rules (queue depth > 10, error rate > 5%, disk > 85%)

#### Phase 2I — Notifications Backend
- FCM service (NestJS) — send to topic, send to users, send to all
- New content release notifications (triggered on publish)
- Continue-watching reminders (scheduled)
- Subscription expiry warnings (3 days before)

#### Phase 2J — Admin Tools
- Bulk CSV import/export for content
- Banner management (CRUD + active date range)
- Home section ordering (drag-drop sort_order)
- SEO metadata management

#### Phase 2K — App Version Management
- Force update middleware (check `X-App-Version` header vs `min_android_version` config)
- Maintenance mode API response (503 with retry-after)
- Remote config endpoint (returns `app_config` table as JSON)
- Feature flags

#### Phase 2L — Offline Downloads (Android)
- WorkManager download queue
- DRM-ready offline storage
- Download quality selection
- Download progress UI

#### Phase 2M — Chromecast
- Cast SDK integration in Android
- `CastPlayer` implementation
- Mini controller overlay

#### Phase 2N — Picture-in-Picture
- Android PiP mode on player screen
- Lifecycle handling (save position on PiP enter)

---

## Project File Structure

```
ott-platform/                     202 files total
├── SETUP.md                      ← Full deployment guide
├── .env.example                  ← ALL env vars documented
├── docker-compose.yml            ← All 11 services
├── .gitignore
│
├── backend/                      91 TypeScript files
│   └── src/
│       ├── auth/                 6 files — JWT, refresh, strategies
│       ├── users/                7 files — CRUD, devices
│       ├── content/              10 files — movies, series, episodes, watch
│       ├── streaming/            4 files — signed HLS URLs
│       ├── upload/               6 files — multipart R2, presign
│       ├── transcoding/          4 files — BullMQ enqueue, job status
│       ├── search/               5 files — Meilisearch, sync listener
│       ├── recommendations/      3 files — all algorithms
│       ├── subscriptions/        6 files — plans, Razorpay, Play Billing
│       ├── payments/             2 files — Razorpay, Google Play services
│       ├── coupons/              2 files — validation, redemption
│       ├── invoices/             1 file  — HTML invoice → R2
│       ├── common/               12 files — guards, interceptors, filters
│       ├── config/               2 files — app + db config
│       ├── health/               2 files — terminus health checks
│       ├── metrics/              3 files — Prometheus
│       ├── database/
│       │   ├── migrations/       2 SQL files
│       │   └── seeds/            1 file — admin user + test content
│       └── app.module.ts + main.ts
│
├── worker/                       15 TypeScript files
│   └── src/
│       ├── processors/           transcode.processor.ts (7-stage pipeline)
│       ├── services/             ffmpeg, r2, db, thumbnail
│       ├── types/                job types, rendition profiles
│       └── utils/                cpu-guard, file-utils, logger
│
├── cms-frontend/                 33 files
│   └── src/
│       ├── api/                  client.ts (axios + refresh), endpoints.ts
│       ├── stores/               auth.store.ts, upload.store.ts
│       ├── hooks/                useUploader.ts (chunked multipart)
│       ├── utils/                cn.ts + formatters
│       ├── types/                index.ts (all types)
│       ├── components/
│       │   ├── Layout/           Sidebar.tsx, AppLayout.tsx
│       │   ├── UI/               index.tsx (all primitives)
│       │   ├── DataTable/        DataTable.tsx
│       │   ├── VideoUploader/    VideoUploader.tsx
│       │   └── EncodingQueue/    EncodingQueue.tsx
│       └── pages/
│           ├── Auth/             LoginPage.tsx
│           ├── Dashboard/        Dashboard.tsx
│           ├── Content/          ContentList.tsx, ContentForm.tsx, UploadPage.tsx
│           ├── Users/            UserManagement.tsx
│           ├── Subscriptions/    SubscriptionsPage.tsx
│           ├── Notifications/    NotificationsPage.tsx
│           └── Settings/         SettingsPage.tsx
│
├── android/                      49 Kotlin files
│   └── app/src/main/java/com/ott/app/
│       ├── data/
│       │   ├── local/            TokenStorage.kt, OttDatabase.kt (Room)
│       │   ├── remote/           OttApiService.kt, AuthDto.kt, ContentDto.kt, AuthInterceptor.kt
│       │   └── repository/       Auth, Content, Watch, Stream, Subscription impls
│       ├── domain/
│       │   ├── model/            Content.kt (all models)
│       │   └── repository/       Interfaces + Resource<T>
│       ├── player/               ExoPlayerManager.kt
│       ├── di/                   AppModule.kt (Network + DB + Repos)
│       ├── services/             OttFcmService, NotificationHelper, MediaPlaybackService
│       └── presentation/
│           ├── auth/             AuthScreen.kt, AuthViewModel.kt
│           ├── home/             HomeScreen.kt, HomeViewModel.kt
│           ├── content/          ContentDetailScreen.kt, ContentDetailViewModel.kt
│           ├── player/           PlayerScreen.kt, PlayerViewModel.kt
│           ├── search/           SearchScreen.kt, SearchViewModel.kt
│           ├── profile/          ProfileScreen.kt
│           ├── subscription/     SubscriptionScreen.kt, SubscriptionViewModel.kt
│           ├── splash/           SplashScreen.kt
│           ├── common/           OttColors.kt
│           └── navigation/       AppNavigation.kt
│
├── nginx/
│   ├── nginx.conf                Cloudflare real-IP, gzip, rate limit zones
│   ├── conf.d/api.conf           HTTPS, proxy_pass, rate limiting per endpoint
│   └── conf.d/stream.conf        HLS token verify subrequest location
│
├── monitoring/
│   ├── prometheus/prometheus.yml  Scrape: api:3000, worker:9091, postgres, redis, node
│   └── loki/loki-config.yml       7-day retention, tsdb storage
│
└── scripts/
    ├── vps-setup.sh              UFW, Fail2Ban, Docker, swap, sysctl tuning
    ├── deploy.sh                 Full deploy sequence with health checks
    ├── backup-postgres.sh        pg_dump + gzip, 14-day retention
    ├── restore-postgres.sh       Interactive restore with confirmation
    ├── health-check.sh           Check all 6 services
    └── setup-cron.sh             Daily backup + 5-min health + weekly image prune
```

---

## Key Architecture Decisions (for context)

### Authentication
- **Access token:** 15 minutes, HS256, payload = `{sub, email, role, deviceFingerprint}`
- **Refresh token:** 30 days, stored as SHA256 hash in `devices.refresh_token_hash`
- **Rotation:** Every refresh generates new pair; old token hash invalidated
- **Replay attack:** Token reuse detected → all sessions revoked
- **Device fingerprint:** HMAC-SHA256(deviceId + browser + OS + IP) — CF-Connecting-IP aware

### HLS Streaming Security
- Signed URL = HMAC-SHA256(`r2Path:expires`, CF_SIGNED_URL_SECRET)
- master.m3u8 fetched from R2 by API, all segment URLs rewritten with tokens before serving
- Token TTL: 1 hour (configurable via `hls_token_ttl_seconds` in app_config)
- `/api/v1/stream/verify` endpoint for Nginx `auth_request` (returns 200/401)

### Video Pipeline
```
Upload → R2 raw/ → BullMQ → Worker:
  FFprobe → selectRenditions (no upscale) → transcodeRendition×4
  → extractAudioTracks → extractSubtitles → generateThumbnails
  → generateSpriteSheet → uploadDirectory (R2) → buildMasterPlaylist
  → DB update → publishContent
```

### Payment Flow
```
1. POST /payment/create-order → Razorpay order + pending PaymentEntity
2. Android Checkout.open() → Razorpay UI
3. POST /payment/verify → HMAC verify → DB transaction → subscription + invoice
```

### Search Architecture
- Meilisearch single `content` index
- Fields: title (A), actorNames (B), genres (B), description (C)
- Auto-sync via TypeORM EntitySubscriber (500ms defer)
- Admin `/search/admin/reindex` for full rebuild

### Recommendation Scoring
```
trending:      score = recent_plays_7d×2 + total_plays×0.1 + imdb_rating×10
similar:       score = genre_overlap_count × 100
because_watched: score = genre_overlap_count × 100 (from last 5 watched)
top_rated:     ordered by imdb_rating DESC (≥7.0 filter)
new_releases:  ordered by published_at DESC (last 30 days)
```

---

## Environment Variables Quick Reference

```bash
# MUST change before any deploy:
DOMAIN=ssooss.store               # → your domain
POSTGRES_PASSWORD=CHANGE_ME       # strong password
REDIS_PASSWORD=CHANGE_ME          # strong password
JWT_SECRET=CHANGE_ME              # openssl rand -hex 32
JWT_REFRESH_SECRET=CHANGE_ME      # openssl rand -hex 32
CF_SIGNED_URL_SECRET=CHANGE_ME    # openssl rand -hex 32
MEILISEARCH_KEY=CHANGE_ME         # min 16 chars

# External services (get from their dashboards):
CF_ACCOUNT_ID=                    # Cloudflare account ID
CF_R2_ACCESS_KEY=                 # R2 API token
CF_R2_SECRET_KEY=                 # R2 API secret
CF_R2_ENDPOINT=                   # https://<id>.r2.cloudflarestorage.com
RAZORPAY_KEY_ID=                  # rzp_live_XXX
RAZORPAY_SECRET=                  # from Razorpay dashboard
FIREBASE_SERVICE_ACCOUNT=         # JSON from Firebase console
```

---

## How to Continue in New Session

### Prompt template for new session:

```
I'm building a production OTT platform. I have an existing codebase 
at 68% completion. Here is the full project context:

[paste this entire document]

The project is on Hetzner CX23, domain ssooss.store, using:
- NestJS backend (91 files complete)
- React CMS (33 files complete)  
- Kotlin Android app (49 files complete)
- FFmpeg worker (15 files complete)

Please continue from where we left off. The next items to build are:

[choose from the NOT YET BUILT list above]

Rules:
1. Always provide complete code — no stubs
2. Include all imports
3. Be consistent with the existing patterns described above
4. Use the same naming conventions (camelCase entities, kebab-case files)
5. Every new backend module needs: entity, service, controller, module
6. Android screens need: ViewModel + Screen (Compose)
```

### Recommended next phases in order:
1. **Finish Phase 2F** — Android recommendations integration (HomeViewModel + HomeScreen update)
2. **Phase 2H** — Analytics + Grafana dashboards (high operational value before launch)
3. **Phase 2I** — Notifications backend NestJS service
4. **Phase 2G** — Streaming security hardening
5. **Phase 2K** — App version management (needed before Play Store release)

---

## Quick Commands Reference

```bash
# Deploy
bash /opt/ott/scripts/deploy.sh

# Check all services
docker compose ps
bash scripts/health-check.sh

# API logs
docker compose logs -f api

# Worker logs (FFmpeg output)
docker compose logs -f worker

# Check encoding queue
curl -H "Authorization: Bearer <token>" \
  https://ssooss.store/api/v1/upload/queue-stats

# Trigger reindex
curl -X POST -H "Authorization: Bearer <admin-token>" \
  https://ssooss.store/api/v1/search/admin/reindex

# Manual DB backup
bash scripts/backup-postgres.sh

# Scale workers
docker compose up -d --scale worker=2 worker

# Restart single service
docker compose restart api

# View Swagger (dev only)
http://localhost:3000/api/docs
```

---

## Known Issues / TODOs in Current Code

1. **`analytics` module** — stub only (1 file), needs full implementation
2. **`admin` module** — stub only, needs banner management + bulk import
3. **`notifications` module** — stub only, FCM sending not yet wired
4. **Android `OttApiService`** — missing recommendation endpoints (need to add)
5. **`HomeViewModel`** — currently calls content API directly, should use recommendations API
6. **`SearchScreen.kt`** — complete but doesn't show trending searches from backend yet
7. **Nginx stream gate** — `stream.conf` has the `auth_request` location defined but nginx `conf.d/api.conf` doesn't yet use `auth_request` on HLS segment paths (segments go direct to R2/CDN, so this is optional security hardening)
8. **`device-limit.guard.ts`** — implemented but not yet applied to `auth/login` route
9. **SQL migration** for `search_queries` table referenced in `SearchService` but not in either migration file yet

---

*Project started with the prompt: "Build a production-ready OTT streaming platform similar to Netflix/JioCinema/Prime Video..."*
*Architecture: Claude Sonnet 4.6*
*Total conversation: Phases 1, 2A, 2B, 2C, 2D, 2E, 2F (partial)*
